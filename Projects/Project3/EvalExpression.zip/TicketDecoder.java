import java.util.Scanner;
import java.util.Random;
import java.text.DecimalFormat;
/**
*@author Colin Wallace
* 9/9/19
*/
public class TicketDecoder {
   /**
   * 
   *
   * @param args not used.
   */
   public static void main(String[] args) {
      Scanner userInput = new Scanner(System.in);
      System.out.print("Enter your ticket code: ");
      String x = userInput.nextLine();
      
      DecimalFormat fmt1 = new DecimalFormat("0000000");
      DecimalFormat fmt2 = new DecimalFormat("0%");
      DecimalFormat fmt3 = new DecimalFormat("$#,##0.00");
      String hour;
      String minutes;
      String month;
      String day;
      String year;
      String seat;
      String description;
      String section;
      String row;
      double price;
      double discount;
      double cost;
      int prize;
   
      
      if (x.length() >= 25) {
         x = x.trim();
         price = Double.parseDouble(x.substring(0, 3));
         discount = Double.parseDouble(x.substring(5, 7))
            / 100;
         cost = (1 - discount) * price; 
         
         
         hour = x.substring(7, 9);
         minutes = x.substring(9, 11);
         
         month = x.substring(11, 13);
         day = x.substring(13, 15);
         year = x.substring(15, 19);
         
         seat = x.substring(23, 25);
         section = x.substring(19, 21);
         row = x.substring(21, 23);
         description = x.substring(25);
         
         Random gen = new Random();
         prize = gen.nextInt(999999) + 1; 
                 
         System.out.println("\nGame: " + description + "   Date: " 
            + month + "/" + day + "/" + year 
            + "   Time: " + hour + ":" + minutes);
         System.out.println("Section: " + section + "   Row: "
             + row + "   Seat: " + seat);
         System.out.println("Price: " + fmt3.format(price) 
            + "   Discount: " + fmt2.format(discount) 
            + "   Cost: " + fmt3.format(cost));
         System.out.println("Prize Number: " + prize);
      } else {
         System.out.println("\nInvalid Ticket Code.");
         System.out.println("Ticket code must have at least 26 characters.");
      }
   }
}
