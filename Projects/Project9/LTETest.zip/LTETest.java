import org.junit.Assert;
// import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
*LTE Test.
*@author Colin Wallace
*@version 11/8/19
**/
public class LTETest {



   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
      
   }

   /** A test that always fails. **/
   @Test public void toStringTest() {
      LTE fourg = new LTE("Iphone", 450, 40.00, 5.00, 4);
      LTE fiveg = new LTE("Android", 450, 40.00, 5.00, 5);
      Assert.assertEquals(fourg.toString().contains("Iphone"), true);
      Assert.assertEquals(fiveg.toString().contains("Android"), true);
   }
}
