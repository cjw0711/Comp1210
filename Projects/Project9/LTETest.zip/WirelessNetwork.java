import java.text.DecimalFormat;
/**
*Project 09 Inheritance.
*@author Colin Wallace
*@version 11/8/2019
**/
public abstract class WirelessNetwork {

   protected static int count = 0;
   protected double monthlyCost = 0;
   protected double bandwidth = 0;
   protected String name = "";
   /**
   *@param monthlyCostIn monthlyCost input.
   *@param bandwidthIn bandwidth input.
   *@param nameIn name input.
   **/
   public WirelessNetwork(String nameIn, double bandwidthIn,
       double monthlyCostIn) {
      count++;
      monthlyCost = monthlyCostIn;
      bandwidth = bandwidthIn;
      name = nameIn;
   }
   /**
   *
   *@param nameIn name input.
   **/
   public void setName(String nameIn) {
      name = nameIn;
   }
   /**
   *
   *@param bandwidthIn bandwidth input.
   **/
   public void setBandwidth(double bandwidthIn) {
      bandwidth = bandwidthIn;
   }
   /**
   *
   *@param monthlyCostIn monthlyCost input
   **/
   public void setMonthlyFixedCost(double monthlyCostIn) {
      monthlyCost = monthlyCostIn;
   }
   /**
   *
   *@return returns name.
   **/
   public String getName() {
      return name;
   }
   /**
   *
   *@return returns bandwidth.
   **/
   public double getBandwidth() {
      return bandwidth;
   }
   /**
   *
   *@return returns monthlyCost.
   **/
   public double getMonthlyFixedCost() {
      return monthlyCost;
   }
  
   /**
   *reset count to o.
   **/
   public static void resetCount() {
      WirelessNetwork.count = 0;
   }
   /**
   *
   *@return returns count.
   **/
   public static int getCount() {
      return count;
   }
   /**
   *
   *@return returns output.
   **/
   public String toString() {
      DecimalFormat wirelessnet = new DecimalFormat("#,##0.00##");
      String output;
      output = name + " (" + getClass() + ") Cost: $" 
          + wirelessnet.format(monthlyCost())
          + "\nBandwidth: " + bandwidth + " Mbps";
      return output;
   }
   /**
   *
   *@return nothing.
   **/
   public abstract double monthlyCost(); 
}

