/**
* proj 09 LTE class.
*@author Colin Wallace
*@version 11/8/19
**/

public class LTE extends Cellular {
/**
*
**/
   public static final double COST_FACTOR = 4.0;
 /**
*@param monthlyCostIn monthlyCost input
*@param bandwidthIn bandiwdth input
*@param nameIn name input
*@param timeIn time input
*@param datalimitIn limit input
**/  
   public LTE(String nameIn, double bandwidthIn, double monthlyCostIn, 
      double timeIn, double datalimitIn) {
      super(nameIn, bandwidthIn, monthlyCostIn, timeIn, datalimitIn);
   }
 /**
*@return returns monthlyCost plus datausage minus limit 
   multiplied by constant COST_FACTOR.
**/
   public double monthlyCost() {
      //if (dataUsage() <= datalimit) {
         //return monthlyCost;
      //}
      //else  {
      return (monthlyCost + (dataUsage() - datalimit) * LTE.COST_FACTOR);
      //}
   }
 /**
*@return returns super toString from cellular class.
**/
   public String toString() {
      return super.toString();
   }
}