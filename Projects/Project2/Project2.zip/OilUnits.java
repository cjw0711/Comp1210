import java.util.Scanner;
 /**
*@author Colin Wallace
* Project 02 9-4-19
*/ 
public class OilUnits
{
 /**
 *@param args
 *allows user to enter an amount of oil in ounces,
 *which must not exceed 1 billion,
 *then displays the number of barrels, gallons, quarts, and ounces.
 */
   public static void main(String[] args)
   {
      Scanner reader = new Scanner(System.in);
      int barrel = 0;
      int gallons = 0;
      int quarts = 0;
      int ounces = 0;
      int remaining = 0;
      int totalOunces = 0;
      
      System.out.print("Enter amount of oil in ounces: ");
      totalOunces = reader.nextInt();
      
       // checks to make sure not over 1 billion
      if (totalOunces > 1000000000)
      {
         System.out.println("Amount must not exceed 1,000,000,000.");
         return;
      }
      // conversions
      barrel = (totalOunces / 5376);
      remaining = totalOunces % 5376;
      gallons = (remaining / 128);
      remaining = remaining % 128;
      quarts = (remaining / 32);
      remaining = remaining % 32;
      ounces = remaining;
      
       //displays results
      System.out.println("Oil amount in units: ");
      System.out.println("\tBarrels: " + barrel);
      System.out.println("\tGallons: " + gallons);
      System.out.println("\tQuarts: " + quarts);
      System.out.println("\tOunces: " + ounces);
      System.out.print(totalOunces 
         + " oz = (" + barrel + " bl * 5376 oz)" 
         + " + (" + gallons + " gal * 128 oz)" 
         + " + (" + quarts + " qt * 32 oz)" 
         + " + (" + ounces + " oz)");
   }
}