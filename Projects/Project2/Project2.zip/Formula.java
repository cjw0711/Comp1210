import java.util.Scanner;
/**
*@author Colin Wallace
* Project 02 9-4-19
*/   
public class Formula {
  /**
* @param args
* inputs values of type double for x, y, and z and solves
for the result of the indicated formula when xyz is not equal to zero. 
*/ 

   public static void main(String[] args) {
   
      Scanner userInput = new Scanner(System.in);
      double x = 0;
      double y = 0;
      double z = 0;
      double result;
      result = (3 * x + 10.5) * (2 * y + 7.5)
            * (z + 5.5) / (x * y * z);
      
      //expression
      System.out.println("result = (3x + 10.5) "
         + "(2y + 7.5) (z + 5.5) / xyz");
         
      //prompt user to enter x value
      System.out.print("\tEnter x: ");
      x = userInput.nextDouble();
      
      //prompt user to enter y value
      System.out.print("\tEnter y: ");
      y = userInput.nextDouble();
      
      //prompt user to enter z value
      System.out.print("\tEnter z: ");
      z = userInput.nextDouble();
      //Calculates result
      if (x * y * z == 0) {
         result = 0;
         System.out.println("result = " + result);
      }
      else {
         result = 
            +(3 * x + 10.5) * (2 * y + 7.5)
            * (z + 5.5) / (x * y * z);  
         System.out.println("result = " + result); 
      }
     
   }
}     
