import java.util.Scanner;
import java.io.FileNotFoundException;
/**  
*@author Colin Wallace
* 10/2/19
*proj07
*/
public class IceCreamConeList2MenuApp
{
/**
 * 
 * @param args - is not used.
 * @throws FileNotFoundException if the file cannot be opened.
 */
   public static void main(String[] args) throws FileNotFoundException
   {
      String iccListName = "*** no list name assigned ***";
      IceCreamCone[] icclist = new IceCreamCone[100];
      IceCreamConeList2 myiccList = new IceCreamConeList2(iccListName, 
         icclist, 0);
      String fileName = "";
      String code = "";
   
      Scanner scanIn = new Scanner(System.in);
      
      System.out.println("IceCreamCone List System Menu\n"
                       + "R - Read File and Create IceCreamCone List\n"
                       + "P - Print IceCreamCone List\n" 
                       + "S - Print Summary\n"
                       + "A - Add IceCreamCone\n"   
                       + "D - Delete IceCreamCone\n"   
                       + "F - Find IceCreamCone\n"
                       + "E - Edit IceCreamCone\n"
                       + "Q - Quit");
   
      do {
         System.out.print("Enter Code [R, P, S, A, D, F, E, or Q]: ");
         double radius = 0;
         double height = 0;
         String labelIn = "", secondLabel = "";
         
         code = scanIn.nextLine();
         if (code.length() == 0) {
            continue;
         }
         code = code.toUpperCase();
         char codeChar = code.charAt(0);
         
         switch(codeChar) {
            case 'R': // Read in File and Create IceCreamConeList
               System.out.print("\tFile Name: ");
               fileName = scanIn.nextLine();
            
               myiccList = myiccList.readFile(fileName);
            
               System.out.println("\tFile read in and "
                              + "IceCreamCone List created\n");
               break; 
                    
            case 'P': // Print IceCreamConeList
               System.out.println(myiccList);
               break;
               
            case 'S': // Print Summary
               System.out.println("\n" + myiccList.summaryInfo() + "\n");
               break;
               
            case 'A': // add IceCreamCone
               System.out.print("\tLabel: ");
               labelIn = scanIn.nextLine();
               System.out.print("\tRadius: ");
               radius = Double.parseDouble(scanIn.nextLine());
               System.out.print("\tHeight: ");
               height = Double.parseDouble(scanIn.nextLine());
               
               myiccList.addIceCreamCone(labelIn, radius, height);
               
               System.out.println("\t*** IceCreamCone added ***\n");
               break;
         
            case 'D': // Delete IceCreamCone
               System.out.print("\tLabel: ");
               labelIn = scanIn.nextLine();
               IceCreamCone obj = myiccList.findIceCreamCone(labelIn);
               if (obj != null) {
                  secondLabel = obj.getLabel();
                  myiccList.deleteIceCreamCone(labelIn);
                  System.out.println("\t\"" + obj.getLabel() + "\" deleted\n");
               } else {
                  System.out.println("\t\"" + labelIn + "\" not found\n");
               }
               break;
                
            case 'F': // Find IceCreamCone Object  
               System.out.print("\tLabel: ");
               labelIn = scanIn.nextLine();
               if (myiccList.findIceCreamCone(labelIn) != null) {
                  System.out.println(myiccList.findIceCreamCone(labelIn)
                     + "\n");
               } else {
                  System.out.println("\t\"" + labelIn + "\" not found\n");
               }   
               break;   
               
            case 'E': // edit IceCreamCone Object
               System.out.print("\tLabel: ");
               labelIn = scanIn.nextLine();
               System.out.print("\tRadius: ");
               radius = Double.parseDouble(scanIn.nextLine());
               System.out.print("\tHeight: ");
               height = Double.parseDouble(scanIn.nextLine());
            
               if (myiccList.findIceCreamCone(labelIn) != null) {
                  myiccList.editIceCreamCone(labelIn, radius, height);
                  System.out.println("\t\""
                     + labelIn + "\" successfully edited\n");
               }
               else {
                  System.out.println("\t\"" + labelIn + "\" not found\n");
               }
               break;   
                  
            case 'Q': // Quits
               break;
               
            default:
               System.out.println("\t*** invalid code ***\n");
         }
      } while (!code.equalsIgnoreCase("Q"));   
      
   }
}