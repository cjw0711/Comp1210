import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
/**
* Determines various functions of an array of an icecreamcone.
* Proj 07
* @author Colin Wallace
* 10/16/19
*/
public class IceCreamConeList2 {
   private String listName = "";
   private IceCreamCone[] iccArray;
   private int arrayDimensions = 0;
/**
* Constructor for class.
* @param listNameIn the name for the array given.
* @param iccArrayListIn list
*@param arrayDimensionsIn number of ice cream cones
*/   
   public IceCreamConeList2(String listNameIn, 
      IceCreamCone[] iccArrayListIn, int arrayDimensionsIn) {
      listName = listNameIn;
      iccArray = iccArrayListIn;
      arrayDimensions = arrayDimensionsIn;
   }
/**
* Gets the name of the array.
* @return returns the name
*/   
   public String getName() {
      return listName; 
   }
/**
* Gets the number of IceCreamCones in the Array.
* @return returns the number of IceCreamCones.
*/   
   public int numberOfIceCreamCones() {
      return arrayDimensions; 
   }
/**
* Calculates the total surface area of all the IceCreamCone in the array.
* @return returns the total surface area
*/   
   public double totalSurfaceArea() {
      double totalSurfaceArea = 0;
      if (numberOfIceCreamCones() == 0) {
         return 0; }
      for (IceCreamCone i: iccArray) {
         if (i == null) {
            break; }
         totalSurfaceArea += i.surfaceArea();   
      } 
      return totalSurfaceArea;
   }  
/**
* Calculates the total volume of all the IceCreamCones in the array.
* @return returns the total volume
*/   
   public double totalVolume() {
      double totalVolume = 0;
      if (numberOfIceCreamCones() == 0) {
         return 0;
      }
      for (IceCreamCone i: iccArray) {
         if (i == null) {
            break; }
         totalVolume += i.volume();
            
      }
      return totalVolume;    
   }      
/**
* Calculates the average surface area of all the IceCreamCones in the array.
* @return returns the average surface area
*/  
   public double averageSurfaceArea() {
      double averageSurfaceArea = 0;
      if (numberOfIceCreamCones() == 0) {
         return 0;
      }
      return totalSurfaceArea() / numberOfIceCreamCones(); 
   }    
/**
* Calculates the average volume of all the IceCreamCones in the array.
* @return returns the average volume
*/  
   public double averageVolume() {
      double averageVolume = 0;
      if (numberOfIceCreamCones() == 0) {
         return 0; }
      return totalVolume() / numberOfIceCreamCones(); 
   }
/**
* Prints out the name of the list as well as each IceCreamCone in the array.
* @return returns the output as described above
*/   
   public String toString() {
      String output = getName() + "\n";
      int num = numberOfIceCreamCones();
      int i = 0;
      while (i < num) {
         if (iccArray[i] == null) {
            break; }
         output += "\n" + iccArray[i].toString() + "\n";
         i++;
      } 
      return output;
   }
/**
* Prints out the summary of the the array.
* @return returns the summary
*/   
   public String summaryInfo()
   {
      DecimalFormat df = new DecimalFormat("#,##0.0##");
      String result = "";
      result += "----- Summary for " + getName() + " -----"; 
      result += "\nNumber of IceCreamCone Objects: " + numberOfIceCreamCones();
      result += "\nTotal Surface Area: " + df.format(totalSurfaceArea()); 
      result += "\nTotal Volume: "  + df.format(totalVolume());
      result += "\nAverage Surface Area: " + df.format(averageSurfaceArea());
      result += "\nAverage Volume: " + df.format(averageVolume());
      return result;
   }
// start of proj06 new methods 

/**
*gets arraylist of IceCreamCone.
*@return array list of IceCreamCone
*/ 
   public IceCreamCone[] getList() {
      return iccArray;
   }
/**
* Reads file for IceCreamConelist.
* @param fileNameIn for fileName to read
* @return IceCreamConeList
* @throws FileNotFoundException if the file cannot be opened.
*/
   public IceCreamConeList2 readFile(String fileNameIn) 
                                    throws FileNotFoundException {
                                  
      IceCreamCone[] listoficc = new IceCreamCone[100];                         
      Scanner scanF = new Scanner(new File(fileNameIn));
      String label = "";
      double radius = 0;
      double height = 0;
      int i = 0;
      listName = scanF.nextLine();
      
      
      while (scanF.hasNext()) {
         label = scanF.nextLine();
         radius = Double.parseDouble(scanF.nextLine());
         height = Double.parseDouble(scanF.nextLine());
         
         IceCreamCone iccobj = new IceCreamCone(label, radius, height);
         listoficc[i] = iccobj;
         i++;          
      }
      
      IceCreamConeList2 icclist2 = new IceCreamConeList2(listName, 
         listoficc, i); 
      return icclist2;
   }
   
   /**
   *@param label adds label
   *@param height adds the height
   *@param radius adds the radius
   */
   public void addIceCreamCone(String label, double radius, double height) {
      IceCreamCone ic
         = new IceCreamCone(label, radius, height);
      iccArray[arrayDimensions] = ic;
      arrayDimensions++;
   }
   /**
   *finds iceCreamCone in IceCreamConelist.
   *@return returns IceCreamCone
   *@param label input
   */
   public IceCreamCone findIceCreamCone(String label) {
      IceCreamCone result = null;
      for (IceCreamCone i : iccArray) {
         if (i == null) {
            break; }
         if (i.getLabel().equalsIgnoreCase(label)) {
            result = i;
            break;
         }
      }
      return result;
   
   }
   /**
   *edits IceCreamCone.
   *@return IceCreamConeList
   *@param labelIn label input
   *@param heightIn height input
   *@param radiusIn radius input
   */
   public boolean editIceCreamCone(String labelIn, double radiusIn, 
      double heightIn) {
      
      boolean result = false;
      for (IceCreamCone i : iccArray) {
         if (i == null) {
            break; }
         if (i.getLabel().equalsIgnoreCase(labelIn)) {
            i.setRadius(radiusIn);
            i.setHeight(heightIn);
            result = true;
            break;
         }
      }
      return result;
   }
   
  /**
   * Deletes an IceCreamCone from the list.
   * @return true if deleted else return false
   * @param labelIn 
   */    
   public IceCreamCone deleteIceCreamCone(String labelIn) {
      IceCreamCone icc = null;
      
      for (int i = 0; i < arrayDimensions; i++) {
         if (iccArray[i] == null) {
            break; }
         if (iccArray[i].getLabel().equalsIgnoreCase(labelIn)) {
            icc = iccArray[i];
            for (int size = i; size < arrayDimensions - 1; size++) {
               iccArray[size] = iccArray[size + 1];
            }
            iccArray[arrayDimensions - 1] = null;
            arrayDimensions--;
            break;
         }
      }
      return icc;        
   }
}