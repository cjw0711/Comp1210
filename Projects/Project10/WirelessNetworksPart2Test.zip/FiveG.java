/**
*@author Colin Wallace
*@version 11/8/19
* proj 09 fiveG class.
**/

public class FiveG extends Cellular {
/**
  * Cost_FACTOR constant.
     **/ 
   public static final double COST_FACTOR = 5.0;
    /**
*@param monthlyCostIn monthlyCost input.
*@param bandwidthIn bandiwdth input.
*@param nameIn name input.
*@param timeIn time input.
*@param datalimitIn datalimit input.
**/ 
   public FiveG(String nameIn, double bandwidthIn, double monthlyCostIn,
       double timeIn, double datalimitIn) {
      super(nameIn, bandwidthIn, monthlyCostIn, timeIn, datalimitIn);
   }
     /**
     *
     *@return returns monthlyCost plus dataUsage minus limit multiplied 
      by COST_FACTOR multiplied by 3.
     **/ 
   public double monthlyCost() {
      if (dataUsage() <= datalimit) {
         return monthlyCost;
      }
      else  {
         return (monthlyCost 
            + (dataUsage() - datalimit) * FiveG.COST_FACTOR * 3);
      }
   }
}