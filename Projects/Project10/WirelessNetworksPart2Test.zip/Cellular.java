
/**
*proj 09 cellular class.
*@author Colin Wallace
*@version 11/8/19
**/
public class Cellular extends WirelessNetwork {
/**
 *
 *
 **/
   public static final double COST_FACTOR = 1.0;
   protected double time = 0;
   protected double datalimit = 0;
   /**
   *@param nameIn name input
   *@param monthlyCostIn monthlyCost input
   *@param bandwidthIn bandwidth input
   *@param timeIn time input
   *@param datalimitIn limit input
   **/
   public Cellular(String nameIn, 
      double bandwidthIn, double monthlyCostIn, 
         double timeIn, double datalimitIn) {
      super(nameIn, bandwidthIn, monthlyCostIn);
      time = timeIn;
      datalimit = datalimitIn;
   }
  /**
   *
   *@return returns limit
   **/
   public double getDataLimit() {
      return datalimit;
   }
   /**
   *
   *@param datalimitIn datalimit input
   **/
   public void setDataLimit(double datalimitIn) {
      this.datalimit = datalimitIn;
   }
   /**
   *
   *@return returns time.
   **/
   public double getTime() {
      return time;
   }
   /**
   *
   *@param timeIn time input
   **/
   public void setTime(double timeIn) {
      this.time = timeIn;  
   }
   /**
   *
   *@return returns bandwidth divided by 8000 multiplied by time.
   **/
   public double dataUsage() {
      return bandwidth / 8000 * time;
   }
   /**
   *
   *@return returns monthlyCost plus datausage minus limit 
      multiplied by the constant COST_FACTOR.
   **/
   public double monthlyCost() {
      if (dataUsage() <= datalimit) {
         return monthlyCost;
      }
      else  {
         return (monthlyCost 
            + (dataUsage() - datalimit) * Cellular.COST_FACTOR);
      }
   }
   /**
   *
   *@return returns toString output
   **/
   public String toString() {
      String output = super.toString();
      output = output + "\nTime: " + time + " seconds";
      output += "\nData Limit: " + datalimit + " GB";
      output += "\nData Used: " + dataUsage() + " GB";
      return output;
   }
}