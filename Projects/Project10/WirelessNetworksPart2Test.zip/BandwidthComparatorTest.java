import org.junit.Assert;
// import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

   /**
   *proj 10.
   *@author Colin Wallace
   *@version 11/22/19
   **/
public class BandwidthComparatorTest {
   private BandwidthComparator bCC = new BandwidthComparator();


   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }


   /** 
   *Test with -1.
    **/
   @Test public void test1() {
      LTE lT = new LTE("My iPad", 20.0, 1200.0, 2.0, 3.0);
      FiveG fG = new FiveG("My Phone", 80.0, 1200.0, 10.0, 12.0);
      Assert.assertEquals(1, bCC.compare(fG, lT));
      
   }
   /** 
   *zero test 2.
    **/
   @Test public void test2() {
      LTE lT = new LTE("My iPad", 20.0, 1200.0, 2.0, 3.0);
      FiveG fG = new FiveG("My Phone", 80.0, 1200.0, 10.0, 12.0);
      Assert.assertEquals(-1, bCC.compare(lT, fG));
      
   }
   /** 
   *test with 1.
    **/
   @Test public void test3() {
      LTE lT = new LTE("My iPad", 20.0, 1200.0, 2.0, 3.0);
      LTE lTE = new LTE("My Android", 20.0, 1200.0, 2.0, 3.0);
      Assert.assertEquals(0, bCC.compare(lT, lTE));
      
   }
}
