import java.util.Arrays;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;
/**
*wirelessnetworklist class.
*@author Colin Wallace
*@version
**/
public class WirelessNetworkList {
   private String[] invalidRecords;
   private WirelessNetwork[] wirelessList;
   /**
   *
   *
   **/
   public WirelessNetworkList() {
      wirelessList = new WirelessNetwork[0];
      invalidRecords = new String[0];
   }
   /**
   *
   *@return returns invalidRecords.
   **/
   public String[] getInvalidRecordsArray() {
      return invalidRecords;
   }
   /**
   *
   *@return returns wirelessList.
   **/ 
   public WirelessNetwork[] getWirelessNetworksArray() {
      return wirelessList;
   }
   /**
   *
   *@param wirelessNetworkIn wirlessList input.
   **/
   public void addWirelessNetwork(WirelessNetwork wirelessNetworkIn) {
      wirelessList  = Arrays.copyOf(wirelessList, wirelessList.length + 1);
      wirelessList[wirelessList.length - 1] = wirelessNetworkIn;
   }
   /**
   *
   *@param invalidRecordsIn invalidRecords input.
   **/
   public void addInvalidRecord(String invalidRecordsIn) {
      invalidRecords = Arrays.copyOf(invalidRecords,
         invalidRecords.length + 1);
      invalidRecords[invalidRecords.length - 1] = invalidRecordsIn;
   
   }
   /**
   *
   *@param fileNameIn fileName input
   *@throws FileNotFoundException 
   **/
   public void readFile(String fileNameIn) throws FileNotFoundException {
      Scanner scanner = new Scanner(new File(fileNameIn));
      char output;
      double bandwidthIn, monthlyCostIn, modemCostIn, timeIn, datalimitIn;
      String nameIn = "";
      
      
      while (scanner.hasNextLine()) {
         String object = scanner.nextLine();
         Scanner scanFile = new Scanner(object);
         scanFile.useDelimiter(",");
         output = scanFile.next().charAt(0);
        
         switch (output) {
         
            case 'W':
               nameIn = scanFile.next().trim();
               bandwidthIn = Double.parseDouble(scanFile.next().trim());
               monthlyCostIn = Double.parseDouble(scanFile.next().trim());
               modemCostIn = Double.parseDouble(scanFile.next().trim());
               addWirelessNetwork(new WiFi(nameIn, 
                  bandwidthIn, monthlyCostIn, modemCostIn));
               break; 
            case 'C':
               nameIn = scanFile.next().trim();
               bandwidthIn = Double.parseDouble(scanFile.next().trim());
               monthlyCostIn = Double.parseDouble(scanFile.next().trim());
               timeIn = Double.parseDouble(scanFile.next().trim());
               datalimitIn = Double.parseDouble(scanFile.next().trim());
               addWirelessNetwork(new Cellular(nameIn, 
                  bandwidthIn, monthlyCostIn, 
                  timeIn, datalimitIn));
               break;
            case 'L':
               nameIn = scanFile.next().trim();
               bandwidthIn = Double.parseDouble(scanFile.next().trim());
               monthlyCostIn = Double.parseDouble(scanFile.next().trim());
               timeIn = Double.parseDouble(scanFile.next().trim());
               datalimitIn = Double.parseDouble(scanFile.next().trim());
               addWirelessNetwork(new LTE(nameIn, bandwidthIn,
                   monthlyCostIn, timeIn, datalimitIn));
               break;
            case 'F':
               nameIn = scanFile.next().trim();
               bandwidthIn = Double.parseDouble(scanFile.next().trim());
               monthlyCostIn = Double.parseDouble(scanFile.next().trim());
               timeIn = Double.parseDouble(scanFile.next().trim());
               datalimitIn = Double.parseDouble(scanFile.next().trim());
               addWirelessNetwork(new FiveG(nameIn, bandwidthIn,
                   monthlyCostIn, timeIn, datalimitIn));
               break;
               
            default:
               continue;
         }
      }
   }
    /**
   *@return returns output.
   *
   **/ 
   public String generateReport() {
      String output = "-------------------------------"
         + "\nMonthly Wireless Network Report"
         + "\n-------------------------------\n";
      for (int i = 0; i < wirelessList.length; i++)
      {
         output += wirelessList[i] + "\n\n"; 
      }
      return output;
   }
   /**
   *@return returns output.
   *
   **/
   public String generateReportByName() {
      Arrays.sort(wirelessList);
      String output = "-----------------------------------------"
         + "\nMonthly Wireless Network Report (by Name)"
         + "\n-----------------------------------------\n";   
      for (int i = 0; i < wirelessList.length; i++) {
         output += wirelessList[i] + "\n\n";
      }   
      return output;
   }
   /**
   *
   *@return returns output.
   **/
   public String generateReportByBandwidth() {
      Arrays.sort(wirelessList, new BandwidthComparator());
      String output = "----------------------------------------------"
         + "\nMonthly Wireless Network Report (by Bandwidth)"
         + "\n----------------------------------------------\n";
           
      for (int i = 0; i < wirelessList.length; i++) {
         output += wirelessList[i] + "\n\n";
      }
      return output; 
   }
   /**
   *@return returns output.
   *
   **/
   public String generateReportByMonthlyCost() {
      Arrays.sort(wirelessList, new MonthlyCostComparator());
      String output = "-------------------------------------------------"
         + "\nMonthly Wireless Network Report (by Monthly Cost)"
         + "\n-------------------------------------------------\n";
           
      for (int i = 0; i < wirelessList.length; i++) {
         output += wirelessList[i] + "\n\n";
      }   
      return output;
   }
      
}