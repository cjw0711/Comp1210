import org.junit.Assert;
 // import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
*FiveG Test.
*@author Colin Wallace
*@version 11/8/19
**/
public class FiveGTest {


   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }


   /** A test that always fails. **/
   @Test public void defaultTest() {
      FiveG one = new FiveG("My Phone", 450, 40.00, 5.00, 4);
      FiveG two = new FiveG("My Iphone", 450, 4.00, 5.00, 5);
      Assert.assertEquals("", 40.0, one.monthlyCost(), .000001);
      Assert.assertEquals("", 4.00, two.monthlyCost(), .000001);
   }
}
