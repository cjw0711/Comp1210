// import org.junit.Assert;
// import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.io.FileNotFoundException;

/**
   *proj 10.
   *@author Colin Wallace
   *@version 11/22/19
   **/
public class WirelessNetworksPart2Test {


   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }


   /** A test that always fails. 
   @throws FileNotFoundException if file not found.
   **/
   @Test public void test() throws FileNotFoundException {
   
      String[] args1 = {};
      WirelessNetworksPart2.main(args1);
      
      
   }
   /**
   *
   @throws FileNotFoundException if file not found.
   *
   **/
   @Test public void test2() throws FileNotFoundException {
   
      String[] args2 = {"wireless_network_data1.csv"};
      WirelessNetworksPart2.main(args2); 
   }
   /**
   *
   *
   **/
   @Test public void neededTest() {
      WirelessNetworksPart2 app = new WirelessNetworksPart2();
   }
}
