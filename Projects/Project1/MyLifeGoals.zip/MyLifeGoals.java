 /**
 *@author Colin Wallace
 *Project01
 */
public class MyLifeGoals {
/**
* @param args
* Prints my short, medium, and long term goals
*/
   public static void main(String[] args) {
   
      System.out.println("Colin Wallace");
      System.out.println("");
      System.out.println("Graduate with a bachelors with atleast" 
            + " a 3.5 GPA in Computer Science or the major that I want to do." 
            + "Then possibly get my masters.");
      System.out.println("To get a stable income and settle down with a family" 
            + " This is something I would want to achieve later"
            + " on in life after long term goal.");
      System.out.println("My long term goal is to" 
               + "play professional video games.This has always been my dream," 
               + " and every ounce of effort outside school goes to it");
   }
}   

   
