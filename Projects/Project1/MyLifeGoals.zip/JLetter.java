/**
 *@author Colin Wallace
 *Project01
 */
public class JLetter {
/**
* @param args
* Prints the word Java in the shape of a J
*/
   public static void main(String[] args) {
   
   
   
      System.out.println("JAVAJAVAJAVA");
      System.out.println("JAVAJAVAJAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("J     JAVA");
      System.out.println("JA    JAVA");
      System.out.println(" JAVAJAVA");
      System.out.println("  JAVAJA");
   }
}