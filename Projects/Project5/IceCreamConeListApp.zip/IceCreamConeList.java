import java.util.ArrayList;
import java.text.DecimalFormat;
/**
* Determines various functions of an array of an icecreamcone.
* Proj 05
* @author Colin Wallace
* 10/2/19
*/
public class IceCreamConeList
{
   private String listName;
   private ArrayList<IceCreamCone> iccList;
/**
* Constructor for class.
* @param listNameIn the name for the array given.
* @param iccListIn icc list
*/   
   public IceCreamConeList(String listNameIn, ArrayList<IceCreamCone> iccListIn)
   {
      listName = listNameIn;
      iccList = iccListIn;
   }
/**
* Gets the name of the array.
* @return returns the name
*/   
   public String getName()
   {
      return listName; 
   }
/**
* Gets the number of IceCreamCones in the Array.
* @return returns the number of IceCreamCones.
*/   
   public int numberOfIceCreamCones() {
      if (iccList.size() < 1) {
         return 0;
      } 
      else {
         return iccList.size();
      }
   }
/**
* Calculates the total surface area of all the IceCreamCone in the array.
* @return returns the total surface area
*/   
   public double totalSurfaceArea() {
      if (iccList.size() > 0) {
         double total = 0;
         int index = 0;
         while (index < iccList.size()) {
            total += iccList.get(index).surfaceArea();
            index++;
         }
         return total;
      }
      else {
         return 0;
      }
   
   }
/**
* Calculates the total volume of all the IceCreamCones in the array.
* @return returns the total volume
*/   
   public double totalVolume() {
      if (iccList.size() > 0) {
         double output = 0;
         int i = 0;
         while (i < iccList.size()) {
            output += iccList.get(i).volume();
            i++;
         }
         return output;
      }
      else {
         return 0;
      }
   }
/**
* Calculates the average surface area of all the IceCreamCones in the array.
* @return returns the average surface area
*/  
   public double averageSurfaceArea() {
      if (iccList.size() > 0) {
         double output = (totalSurfaceArea() / numberOfIceCreamCones());
         return output;
      }
      else {
         return 0;
      }
   }
/**
* Calculates the average volume of all the IceCreamCones in the array.
* @return returns the average volume
*/  
   public double averageVolume() {
      if (iccList.size() > 0) {
         double output = (totalVolume() / numberOfIceCreamCones());
         return output;
      }
      else {
         return 0.0;
      }
   }
/**
* Prints out the name of the list as well as each IceCreamCone in the array.
* @return returns the output as described above
*/   
   public String toString() {
      int i = 0;
      String output = listName + "\n";
      while (i < numberOfIceCreamCones()) {
      
         output += "\n" + iccList.get(i).toString() + "\n";
         i++;
      }
      output += "\n";
      return output;     
   }
/**
* Prints out the summary of the the array.
* @return returns the summary
*/   
   public String summaryInfo()
   {
      DecimalFormat df = new DecimalFormat("#,##0.0##");
      String result = "";
      result += "----- Summary for " + getName() + " -----"; 
      result += "\nNumber of IceCreamCone Objects: " + numberOfIceCreamCones();
      result += "\nTotal Surface Area: " + df.format(totalSurfaceArea()); 
      result += "\nTotal Volume: "  + df.format(totalVolume());
      result += "\nAverage Surface Area: " + df.format(averageSurfaceArea());
      result += "\nAverage Volume: " + df.format(averageVolume());
      
      return result;
   }
}