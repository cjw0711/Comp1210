import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
/**
* Project 05 IceCreamCone List App.
*@author Colin Wallace
* 9/30/19
*/
public class IceCreamConeListApp
{
/**
*@param args not used.
*@throws FileNotFoundException means file opening failed
*/
   public static void main(String[] args) throws FileNotFoundException
   {
   
      String listName = "";
      String label = "";
      double height = 0;
      double radius = 0;
      
      ArrayList<IceCreamCone> iccObjList = new ArrayList<IceCreamCone>();
      Scanner input = new Scanner(System.in);
      
      System.out.print("Enter file name: ");
      String fileName = input.nextLine();
      
      Scanner scanFile = new Scanner(new File(fileName));
      listName = scanFile.nextLine();
      
      while (scanFile.hasNext()) { 
         label = scanFile.nextLine();
         radius = Double.parseDouble(scanFile.nextLine());
         height = Double.parseDouble(scanFile.nextLine());
         
         
         
         IceCreamCone iccObj = new IceCreamCone(label, radius, height);
         iccObjList.add(iccObj); 
      }
      
      IceCreamConeList iccList = new IceCreamConeList(listName, iccObjList); 
      System.out.println("\n" + iccList.toString());
      System.out.println(iccList.summaryInfo());
   }
}  
    
      
