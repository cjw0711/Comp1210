import org.junit.Assert;
// import org.junit.Before;
import org.junit.Test;
// import static org.junit.Assert.*;

/**
*@author Colin Wallace
*@version 10/22/19
*Test File for IceCreamCone class.
*/
public class IceCreamConeTest {
   /**
   *Test for getLabel.
   */
   @Test public void getLabelTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertEquals("getLabelTest", "Ex1", icc.getLabel()); }
   /**
   *Test for setLabel.
   */
   @Test public void setLabelTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertTrue("", icc.setLabel("Ex2"));
      Assert.assertFalse("", icc.setLabel(null)); 
   }
   
   /**
   *Test for setRadius.
   */
   @Test public void setRadiusTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertTrue(" ", icc.setRadius(1));
      Assert.assertFalse(" ", icc.setRadius(0));
   }  
   /**
   *Test for getRadius.
   */
   @Test public void getRadiusTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertEquals("", 1, icc.getRadius(), 0.000001);
   }
   /**
   *Test for getHeight.
   */
   @Test public void getHeightTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertEquals("getHeighTest", 2, icc.getHeight(), 0.000001);
   }
   /**
   *Test for setHeight.
   */
   @Test public void setHeightTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertTrue(" ", icc.setHeight(1));
      Assert.assertFalse(" ", icc.setHeight(0));
   }  
   /**
   *Test for volume.
   */
   @Test public void volumeTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertEquals(" ", 4.1887902, icc.volume(), 0.0000001);
   }
   /**
   *Test for surfaceArea.
   */
   @Test public void surfaceAreaTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertEquals(" ", 13.308, 
         icc.surfaceArea(), 0.0000001);
   }  
   /**
   *Test for getCount.
   */
   @Test public void getCountTest() {
      IceCreamCone.resetCount();
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertEquals(" ", 1, IceCreamCone.getCount());
   }
   /**
   *Test for resetCount.
   */
   @Test public void resetCountTest() {
      IceCreamCone.resetCount();
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      IceCreamCone.resetCount();
      Assert.assertEquals(" ", 0, IceCreamCone.getCount());
   }
   /**
   *Test for hashCode.
   */
   @Test public void hashCodeTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertEquals("", 0, icc.hashCode());
   }
    /**
   *Test for toString.
   */  
   @Test public void toStringTest() {
      IceCreamCone icc = new IceCreamCone("Ex 1", 1, 2);
      Assert.assertEquals("", true, icc.toString().contains("Ex 1"));
   }
   /**
   *Test for equals.
   */
   @Test public void equalsTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      IceCreamCone t = new IceCreamCone("Ex1", 1, 2);
      Assert.assertTrue("", t.equals(icc));
      
      t = new IceCreamCone("Ex2", 1, 2);
      Assert.assertFalse("", t.equals(icc));
      
      t = new IceCreamCone("Ex1", 2, 2);
      Assert.assertFalse("", t.equals(icc));
      
      t = new IceCreamCone("Ex1", 1, 3);
      Assert.assertFalse("", t.equals(icc));
      
      Object iccobj = new Object();
      Assert.assertFalse(t.equals(iccobj));
   }  
/**
*Test for getters.
*/
   @Test public void gettersTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      Assert.assertEquals("Ex1", icc.getLabel());
      Assert.assertEquals(2, icc.getHeight(), 0.000001);
      Assert.assertEquals(1, icc.getRadius(), 0.000001);
      
   }
   /**
    *Test for setters.
    */
   @Test public void settersTest() {
      IceCreamCone icc = new IceCreamCone("Ex1", 1, 2);
      icc.setLabel("Ex1");
      icc.setHeight(2);
      icc.setRadius(1);
      Assert.assertEquals("Ex1", icc.getLabel());
      Assert.assertEquals(2, icc.getHeight(), 0.000001);
      Assert.assertEquals(1, icc.getRadius(), 0.000001);
   }
}
