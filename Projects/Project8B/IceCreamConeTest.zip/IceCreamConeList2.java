import java.text.DecimalFormat;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
*Proj 08B.
*adds on to proj07 with 4 new methods
*@author Colin Wallace
*@version 10/30/19
**/
public class IceCreamConeList2 {
   private int arrayDimensions = 0;
   private String listName = "";
   private IceCreamCone[] iccArray = new IceCreamCone[100];
/**
*Constructor.
*@param listNameIn list name
*@param iccArrayListIn iccArray
*@param arrayDimensionsIn array dimensions
*/   
   public IceCreamConeList2(String listNameIn, 
      IceCreamCone[] iccArrayListIn, int arrayDimensionsIn) {
      iccArray = iccArrayListIn;
      arrayDimensions = arrayDimensionsIn;
      listName = listNameIn;
   }
/**
*Gets name.
*@return returns name.
*/   
   public String getName() {
      return listName; 
   }
/**
*gets list of IceCreamCone.
*@return iccArray.
*/ 
   public IceCreamCone[] getList() {
      return iccArray;
   }
/**
*The number of IceCreamCones in the Array.
*@return returns the number of IceCreamCones.
*/   
   public int numberOfIceCreamCones() {
      return arrayDimensions; 
   }
/**
*Prints out the name of the list along with IceCreamCones.
*@return returns the output
*/   
   public String toString() {
      String output = getName() + "\n";
      int i = 0;
      int num = numberOfIceCreamCones();
      while (i < num) {
         if (iccArray[i] == null) {
            break; }
         output += "\n" + iccArray[i].toString() + "\n";
         i++;
      } 
      return output;
   }
/**
*Prints out a summary of info about the IceCreamCones.
*@return returns the summary.
*/   
   public String summaryInfo()
   {
      DecimalFormat fmt = new DecimalFormat("#,##0.0##");
      String result = "";
      
      result += "----- Summary for " + getName() + " -----"; 
      result += "\nNumber of IceCreamCone Objects: " + numberOfIceCreamCones();
      result += "\nTotal Surface Area: " + fmt.format(totalSurfaceArea()); 
      result += "\nTotal Volume: "  + fmt.format(totalVolume());
      result += "\nAverage Surface Area: " + fmt.format(averageSurfaceArea());
      result += "\nAverage Volume: " + fmt.format(averageVolume());
      
      return result;
   }
/**
* Reads file for IceCreamConelist2 class.
* @param fileNameIn reads filename
* @return icclist2
* @throws FileNotFoundException if file can not be read in.
*/
   public IceCreamConeList2 readFile(String fileNameIn) 
      throws FileNotFoundException { 
                                                                          
      IceCreamCone[] iCList = new IceCreamCone[100];                      
      Scanner scanner = new Scanner(new File(fileNameIn));
      String label = "";
      listName = scanner.nextLine();  
      int i = 0;
      double radius = 0;
      double height = 0;
      while (scanner.hasNext()) {
         label = scanner.nextLine();
         radius = Double.parseDouble(scanner.nextLine());
         height = Double.parseDouble(scanner.nextLine());
         
         IceCreamCone iccobject = new IceCreamCone(label, radius, height);
         iCList[i] = iccobject;
         i++;          
      }
      IceCreamConeList2 icArray = new IceCreamConeList2(listName, 
         iCList, i); 
      return icArray;
   }
/**
*TotalSurfaceArea of IceCreamCone.
*@return returns totalSurfaceArea.
*/   
   public double totalSurfaceArea() {
      double totalSurfaceArea = 0;
      if (numberOfIceCreamCones() == 0) {
         return 0; }
      for (IceCreamCone i: iccArray) {
         if (i == null) {
            break; }
         totalSurfaceArea += i.surfaceArea();   
      } 
      return totalSurfaceArea;
   }  
    
/**
* averageSurfaceArea of IceCreamCone.
* @return returns totalSurfaceArea / numberOfIceCreamCones = averageSurfaceArea.
*/  
   public double averageSurfaceArea() {
      double averageSurfaceArea = 0;
      if (numberOfIceCreamCones() == 0) 
      {
         return 0;
      }
      return totalSurfaceArea() / numberOfIceCreamCones(); 
   }
/**
* totalVolume of IceCreamCone.
* @return totalVolume
*/   
   public double totalVolume() {
      double totalVolume = 0;
      if (numberOfIceCreamCones() == 0) {
         return 0;
      }
      for (IceCreamCone i: iccArray) {
         if (i == null) {
            break; }
         totalVolume += i.volume();
            
      }
      return totalVolume;    
   }      
/**
* averageVolume of IceCreamCone.
*@return returns the totalVolume / numberOfIceCreamCones = averageVolume
*/  
   public double averageVolume() {
      double averageVolume = 0;
      if (numberOfIceCreamCones() == 0) {
         return 0; }
      return totalVolume() / numberOfIceCreamCones(); 
   }
   /**
   *@param label String label.
   *@param height double height.
   *@param radius double radius.
   */
   public void addIceCreamCone(String label, double radius, double height) {
      IceCreamCone iC
         = new IceCreamCone(label, radius, height);
      iccArray[arrayDimensions] = iC;
      arrayDimensions++;
   }
   /**
   *Deletes an IceCreamCone.
   *@return returns icc
   *@param labelIn 
   */    
   public IceCreamCone deleteIceCreamCone(String labelIn) {
      IceCreamCone iCC = null;
      
      for (int i = 0; i < arrayDimensions; i++) {
         if (iccArray[i].getLabel().equalsIgnoreCase(labelIn)) {
            iCC = iccArray[i];
            for (int index = i; index < arrayDimensions - 1; index++) {
               iccArray[index] = iccArray[index + 1];
            }
            iccArray[arrayDimensions - 1] = null;
            arrayDimensions--;
            break;
         }
      }
      return iCC;        
   }
   /**
   *finds iceCreamCone in IceCreamConelist.
   *@return returns result
   *@param label getLabel
   */
   public IceCreamCone findIceCreamCone(String label) {
      for (int i = 0; i < arrayDimensions; i++) {
         if (iccArray[i].getLabel().equalsIgnoreCase(label)) {
            return iccArray[i];
         }
      }
      return null;
   }
   /**
   *IceCreamCone edit method.
   *@return returns result
   *@param labelIn label input
   *@param heightIn height input
   *@param radiusIn radius input
   */
   public boolean editIceCreamCone(String labelIn, double radiusIn, 
      double heightIn) {
   
      
      boolean result = false;
      for (IceCreamCone i : iccArray) {
         if (i == null) {   
            break; }
         if (i.getLabel().equalsIgnoreCase(labelIn)) {
            i.setRadius(radiusIn);
            i.setHeight(heightIn);
            result = true;
            break;
         }
      }
      return result;
   }
   //Proj08B from here down
   /**
   *finds ice cream cone wtih shorest radius.
   *@return returns shortestRadius
   **/
   public IceCreamCone findIceCreamConeWithShortestRadius() {
      if (arrayDimensions > 0)
      {
         return null;
      }
      IceCreamCone sRad = iccArray[0];
      int i = 0;
      while (i < arrayDimensions)
      {
         if (!(sRad.getRadius() <= iccArray[i].getRadius()))
         {
            sRad = iccArray[i];
         }
         
         i++;
      }
      return sRad;
   }
   /**
   * finds ice cream cone with longest radius.
   *@return returns longestRadius.
   **/
   // change sign on greater
   public IceCreamCone findIceCreamConeWithLongestRadius() {
      if (arrayDimensions > 0)
      {
         return null;
      }
      IceCreamCone lRad = iccArray[0];
      int i = 0;
      while (i < arrayDimensions)
      {
         if (!(lRad.getRadius() > iccArray[i].getRadius()))
         {
            lRad = iccArray[i];
         }
         
         i++;
      }
      return lRad;
   }
   /**
   * finds icecreamcone with greatest volume.
   *@return returns iccArray index or null.
   */
   public IceCreamCone findIceCreamConeWithLargestVolume() {
      if (arrayDimensions > 0)
      {
         return null;
      }
      IceCreamCone lVolume = iccArray[0];
      int i = 0;
      while (i < arrayDimensions)
      {
         if (!(lVolume.volume() > iccArray[i].volume()))
         {
            lVolume = iccArray[i];
         }
         
         i++;
      }
      return lVolume;
      
   }
   /**
   * finds icecreamcone with the smallest volume.
   *@return returns iccArray index or null.
   **/
   public IceCreamCone findIceCreamConeWithSmallestVolume() {
      if (arrayDimensions > 0)
      {
         return null;
      }
      IceCreamCone sVolume = iccArray[0];
      int i = 0;
      while (i < arrayDimensions)
      {
         if (!(sVolume.volume() <= iccArray[i].volume()))
         {
            sVolume = iccArray[i];
         }
         
         i++;
      }
      return sVolume;
      
   }
}