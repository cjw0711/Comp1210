import org.junit.Assert;
// import static org.junit.Assert.*;
import org.junit.Before;
import java.io.FileNotFoundException;
import org.junit.Test;


/**
*Test file for IceCreamConeList Test.
*@author Colin Wallace
*@version 10/30/19
*/
public class IceCreamConeList2Test {

// first is longest, second is shortest
   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }
   /**
   *Test for getName.
   **/
   @Test public void getNameTest() {
   
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List", 
         iArray, 1);
      
      Assert.assertEquals("getListName Test",
                           "Test List", iccArray.getName());
   }
    /**
   *Test for findIceCreamConeWithShortestRadius.
   **/
   @Test public void findIceCreamConeWithShortestRadius() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 0);
      Assert.assertEquals("Shortest Radius Test", iArray[0], 
                           iArray2.findIceCreamConeWithShortestRadius());
   
   }
   /**
   * findIceCreamConeWithShortestRadius False Test.
   **/
   @Test public void findIceCreamConeWithShortestRadiusFalse() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 4);
      Assert.assertEquals("Shortest Radius Test", null, 
                           iArray2.findIceCreamConeWithShortestRadius());
   
   }

   /**
   *Test for findIceCreamConeWithLongestRadius.
   **/
   @Test public void findIceCreamConeWithLongestRadius() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 2);
      Assert.assertEquals("Longest Radius Test", null, 
                           iArray2.findIceCreamConeWithLongestRadius());
   
   }
   /**
   *findIceCreamConeWithLongestRadius False Test.
   **/
   @Test public void findIceCreamConeWithLongestRadiusFalse() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 1);
      Assert.assertEquals("Longest Radius Test", null, 
                           iArray2.findIceCreamConeWithLongestRadius());
   
   }
   /**
   *Test for toString.
   **/
   @Test public void toStringTest() {
   
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List", 
         iArray, 5);
      
      Assert.assertEquals("toString Test", false,
          iccArray.toString().contains("Ex1, 5, 6"));
   }
   /**
   *Test for summaryInfo.
   **/
   @Test public void summaryInfoTest() {
   
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List",
          iArray, 5);
      
      Assert.assertEquals("summaryInfo Test", false,
          iccArray.summaryInfo().contains("Number of IceCreamCone Objects: 3"));
   }
   /**
   *Test for readFile.
   *@throws FileNotFoundException throws FileNotFoundException
   **/
   @Test public void readFileTest() throws FileNotFoundException {
   
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List", null, 0);
      iccArray = iccArray.readFile("IceCreamCone_data_1.txt");
      Assert.assertEquals("readFile Test", "IceCreamCone Test List", 
         iccArray.getName());
   }
   /**
   *Test for totalVolume.
   **/
   @Test public void totalVolume() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4,
          900);
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List",
          iArray, 0);
      Assert.assertEquals("totalVolume Test",
         1.0E-6, 0.000001, iccArray.totalSurfaceArea());
   }
   /**
   *Test for totalSurfaceArea.
   **/
   @Test public void totalSurfaceArea() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List",
          iArray, 0);
      Assert.assertEquals("totalSurface Area Test",
         1.0E-6, 0.000001, iccArray.totalSurfaceArea());
   }
   /**
   *Test for averageVolume.
   **/
   @Test public void averageVolume() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List",
          iArray, 3);
      Assert.assertEquals("averageVolume Test", 6098510.426238592,
         iccArray.averageVolume(), 0.000001);
   }
   /**
   *Test for averageVolume False.
   **/
   @Test public void averageVolumeFalseTest() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 0);
      Assert.assertEquals("averageVolume False Test", 0,
          iArray2.averageVolume(), 0.1);
   }
   /**
   *Test for averageSurfaceArea.
   **/
   @Test public void averageSurfaceArea() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List", 
         iArray, 1);
      Assert.assertEquals("averageVolume Test", 1.8295531278715774E7, 
         iccArray.averageVolume(), 0.000001);
   }
   /**
   *False Test for averageSurfaceArea.
   **/
   @Test public void averageSurfaceAreaFalseTest() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List",
          iArray, 0);
      Assert.assertEquals("averageSurfaceArea False Test",
          iArray2.averageSurfaceArea(), 0, 0.000001);
   }
   /**
   *Test for addIceCreamCone.
   **/
   @Test public void addIceCreamCone() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List",
          iArray, 3);
      IceCreamCone i = new IceCreamCone("Ex 4", 5, 7);
      iccArray.addIceCreamCone("Ex 4", 5, 7);
      IceCreamCone[] iC = iccArray.getList();
      
      Assert.assertEquals("addIceCreamCone Test", i, iC[3]);
   }
   /**
   *Test for findIceCreamCone.
   @throws FileNotFoundException for when a file can not be found.
   **/
   @Test public void findIceCreamCone() throws FileNotFoundException {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 0);
      Assert.assertEquals("Test", null,
         iArray2.findIceCreamCone("Ex1"));
   }
   
     /** A test of find Conical Frustum when false. **/
   @Test public void findIceCreamConeFalseTest() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 2);
      Assert.assertEquals("Test", null, 
                           iArray2.findIceCreamCone("Ex 3"));
   }
   /**
   *Test for editIceCreamCone.
   **/
   @Test public void editIceCreamCone() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 3);
      iArray2.editIceCreamCone("Ex1", 5, 6);
      Assert.assertEquals("Test", 6, 
                           iArray[0].getHeight(), 0.000001);
   }
   /**
   *Test for edit IceCreamCone False.
   **/
   @Test public void editIceCreamConeFalseTest() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 5);
      iArray2.editIceCreamCone("Ex1", 5, 6);
      Assert.assertFalse(iArray2.editIceCreamCone("Ex 4", 6, 7));
   }                   
   /**
   *Test for deleteIceCreamCone.
   **/
   @Test public void deleteIceCreamCone() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List",
          iArray, 1);
      iccArray.deleteIceCreamCone("Ex 2");
      Assert.assertEquals("DeleteIceCreamCone Test", iArray[1], iArray[1]);
   }
   /**
   *Test for delete ice cream cone false.
   **/
   @Test public void deleteIceCreamConeFalse() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 2);
      iArray2.deleteIceCreamCone("Ex 4");
      Assert.assertEquals("deleteIceCreamConeFalseTest", iArray[2], iArray[2]);
   }
   /**
   *Test for findIceCreamConeWithSmallestVolume.
   **/
   @Test public void findIceCreamConeWithSmallestVolume() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 0);
      Assert.assertEquals("smallestVolumeTest", iArray[0], 
         iArray2.findIceCreamConeWithSmallestVolume());
   
   }
   /**
   *find ice cream cone with smallest volume false test.
   **/
   @Test public void findIceCreamConeWithSmallestVolumeFalse() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List", iArray, 4);
      Assert.assertEquals("smallestVolumeFalseTest", null, 
         iArray2.findIceCreamConeWithSmallestVolume());
   
   }
   /**
   *Test for findIceCreamConeWithLargestVolume.
   **/
   @Test public void findIceCreamConeWithLargestVolume() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List",
          iArray, 0);
      Assert.assertEquals("findIceCreamConeWithLargestVolume Test",  	
          iArray[0], iArray2.findIceCreamConeWithLargestVolume());
   }
   /**
   *Test for find ice cream cone with largest volume false.
   **/
   @Test public void findIceCreamConeWithLargestVolumeFalse() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4, 900);
      IceCreamConeList2 iArray2 = new IceCreamConeList2("Test List",
          iArray, 0);
      Assert.assertEquals("findIceCreamConeWithLargestVolume Test",  	
          iArray[0], iArray2.findIceCreamConeWithLargestVolume());
   }
   /**
   *Test for numberOfIceCreamCones.
   **/
   @Test public void numberOfIceCreamCones() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test", iArray, 3);
      Assert.assertEquals("numberOfIceCreamCones Test", 3,
          iccArray.numberOfIceCreamCones());
   }
   /**
   *Test for getters.
   **/
   @Test public void gettersTest() {
      IceCreamCone[] iArray = new IceCreamCone[100];
      iArray[0] = new IceCreamCone("Ex1", 5, 6);
      iArray[1] = new IceCreamCone("Ex 2", 12.3, 25.5);
      iArray[2] = new IceCreamCone("Ex 3", 123.4,
         900);
      IceCreamConeList2 iccArray = new IceCreamConeList2("Test List",
          iArray, 2);
      Assert.assertArrayEquals("gettersTest", iArray, iccArray.getList());
         
      Assert.assertEquals("Test List", iccArray.getName());
      
      
   }
}
