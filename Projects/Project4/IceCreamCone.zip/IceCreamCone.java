import java.text.DecimalFormat;
/**
* Determines various functions of an IceCreamCone.
* Project 4
* @author Colin Wallace
*  9/18/19
*/
public class IceCreamCone
{
//Instance Variables
   private String label = "";
   private double radius = 0; 
   private double height = 0;

/**
* Constructor for IceCreamCone.
* @param labelIn the label for the IceCreamCone.
* @param radiusIn the radius for the IceCreamCone.
* @param heightIn the height of the IceCreamCone.
*/
   public IceCreamCone(String labelIn, double radiusIn, double heightIn)
   {
      setLabel(labelIn);
      setRadius(radiusIn);
      setHeight(heightIn);
   }
/**
* Gets the label for the IceCreamCone.
* @return Returns the String variable label.
*/   
   public String getLabel()
   {
      return label;
   }
/**
* Sets the label for the IceCreamCone.
* @param labelIn the label for the IceCreamCone.
* @return Returns boolean to tell if set or not.
*/   
   public boolean setLabel(String labelIn)
   {
      if (labelIn == null)
      {
         return false;
      }
      else
      {
         label = labelIn.trim();
         return true;
      }
   }
/**
* Gets the radius for the IceCreamCone.
* @return returns the double variable radius.
*/   
   public double getRadius()
   {
      return radius;
   }
/**
* Sets the radius for the IceCreamCone.
* @param radiusIn the radius for the IceCreamCone.
* @return setRadius
*/
   public boolean setRadius(double radiusIn)
   {
      if (radiusIn > 0)
      {
         radius = radiusIn;
         return true;
      }
      else 
      {
         return false;
      }
   }
   /**
   * Gets the height for the IceCreamCone.
   *@return returns the double variable height.
   */ 
   public double getHeight()
   {
      return height;
   }
/**
* Sets the height for the IceCreamCone.
* @param heightIn the height for the IceCreamCone.
* @return setHeight
*/
   public boolean setHeight(double heightIn)
   {
      if (heightIn > 0) 
      {
         height = heightIn;
         return true;
      }
      else
      { 
         return false; 
      }
   }
   /**
   * Calculates the surface Area of the IceCreamCone.
   * @return returns the double variable surfaceArea
   */
   public double surfaceArea() 
   {
      double ca = Math.PI * radius * Math.sqrt(height * height 
         + radius * radius);
      double ha = 2 * Math.PI * radius * radius;
      double a = ca + ha;
      return a;
   }
/**
* Calculates the volume of the IceCreamCone.
* @return returns the double variable volume.
*/
   public double volume()
   {
      double cv = height * Math.PI * radius * radius / 3;
      double hv = 2 * Math.PI * radius * radius * radius / 3;
      double v = cv + hv;
      return v;
   }
/**
* toString method.
*@return Returns a string containing information about IceCreamCone.
*/
   public String toString()
   {
      String output = "";
      DecimalFormat formatter = new DecimalFormat("#,##0.0######");
      output = "IceCreamCone "  + "\"" 
             + label + "\" with radius = " 
             + formatter.format(radius) + " and height = " 
             + formatter.format(height) + (" units has: ")
             + "\n\tsurface area = " 
             + formatter.format(surfaceArea())
             + " square units" 
             + ("\n\tvolume = " + formatter.format(volume()) + " cubic units");
             
      return output;
   }
}