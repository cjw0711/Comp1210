import java.util.Scanner;
/**
* Application to create a IceCreamCone from user input.
* Project 04
* @version 9/18/19
* @author Colin Wallace
*/
public class IceCreamConeApp
{
/**
* Prints to Standard Output.
* @param args Command Line Arguments not used. 
*/
   public static void main(String[] args)
   {
   //variables that declare
      double radius = 0; 
      double height = 0;
      String label;
      Scanner myScanner = new Scanner(System.in);
      
      System.out.print("Enter label, radius," 
         + " and height for an ice cream cone.");
      System.out.print("\n\tlabel: ");
      label = myScanner.nextLine();
      System.out.print("\tradius: ");
      radius = Double.parseDouble(myScanner.nextLine());
      if (radius <= 0)
      {
         System.out.println("Error: radius must be greater than 0.");
         return;
      }   
      System.out.print("\theight: ");
      height = Double.parseDouble(myScanner.nextLine());
      if (height <= 0)
      {
         System.out.println("Error: height must be greater than 0.");
         return;
      }
      IceCreamCone myIceCreamCone = new IceCreamCone(label, radius, height); 
      System.out.print("\n" + myIceCreamCone);
   }
}