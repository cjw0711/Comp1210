import java.text.DecimalFormat;
/**
*Project 08A.
*@author Colin Wallace
*@version 10/22/19
*/
public class IceCreamCone
{
   private String label = "";
   private double radius = 0; 
   private double height = 0;
   private static int count = 0;

/**
* Constructor for IceCreamCone.
* @param labelIn label for IceCreamCone.
* @param radiusIn radius for IceCreamCone.
* @param heightIn height of IceCreamCone. 
*/
   public IceCreamCone(String labelIn, double radiusIn, double heightIn)
   {
      setLabel(labelIn);
      setRadius(radiusIn);
      setHeight(heightIn);
      count++;
   }
/**
*Gets the label for an IceCreamCone.
*@return Returns the String variable label.
*/   
   public String getLabel()
   {
      return label;
   }
/**
*Sets label for IceCreamCone.
*@param labelIn label Input for an IceCreamCone.
*@return Returns boolean
*/   
   public boolean setLabel(String labelIn)
   {
      if (labelIn == null)
      {
         return false;
      }
      else
      {
         label = labelIn.trim();
         return true;
      }
   }
/**
*Gets radius for IceCreamCone.
*@return returns the variable radius.
*/   
   public double getRadius()
   {
      return radius;
   }
/**
*Sets radius for IceCreamCone.
*@param radiusIn radius for IceCreamCone.
*@return setRadius
*/
   public boolean setRadius(double radiusIn)
   {
      if (radiusIn > 0)
      {
         radius = radiusIn;
         return true;
      }
      else 
      {
         return false;
      }
   }
   /**
   *Gets height for IceCreamCone.
   *@return returns variable height.
   */ 
   public double getHeight()
   {
      return height;
   }
/**
*Sets height for IceCreamCone.
*@param heightIn the height for an IceCreamCone.
*@return setHeight
*/
   public boolean setHeight(double heightIn)
   {
      if (heightIn > 0) 
      {
         height = heightIn;
         return true;
      }
      else
      {
         return false; 
      }
   }
   /**
   *volume of IceCreamCone.
   *@return returns volume 
   */
   public double volume()
   {
      double hv = 2 * Math.PI * radius * radius * radius / 3;
      double cv = height * Math.PI * radius * radius / 3;
      double v = cv + hv;
      return v;
   }
   /**
   *surface Area of IceCreamCone.
   *@return returns area
   */
   public double surfaceArea() 
   {
      double ca = Math.PI * radius * Math.sqrt(height * height 
         + radius * radius);
      double ha = 2 * Math.PI * radius * radius;
      double a = ca + ha;
      return a;
   }
/**
*@return Returns a string for IceCreamCone.
*/
   public String toString()
   {
      String output = "";
      DecimalFormat fm = new DecimalFormat("#,##0.0######");
      output = "IceCreamCone "  + "\"" 
             + label + "\" with radius = " 
             + fm.format(radius) + " and height = " 
             + fm.format(height) + (" units has: ")
             + "\n\tsurface area = " 
             + fm.format(surfaceArea())
             + " square units" 
             + ("\n\tvolume = " 
             + fm.format(volume()) + " cubic units");     
      return output;
   }
//Start of methods for proj 8A
      /**
      *@param obj checks obj
      *@return returns boolean
      */
   public boolean equals(Object obj) {
   
      if (!(obj instanceof IceCreamCone)) {
         return false;
      }
      else {
         IceCreamCone icc = (IceCreamCone) obj;
         return (label.equalsIgnoreCase(icc.getLabel())
            && Math.abs(radius - icc.getRadius()) < .000001
            && Math.abs(height - icc.getHeight()) < .000001);
      }
   }
    /**
    *
    *@return returns 0
    */
   public int hashCode() 
   {
      return 0;
   } 
   /**
   *
   *@return returns count
   */   
   public static int getCount() 
   {
      return count;
   }
   /**
   *sets count equal to 0.
   *
   */
   public static void resetCount() 
   {
      count = 0;
   }
}