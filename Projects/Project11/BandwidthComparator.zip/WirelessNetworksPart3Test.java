import org.junit.Assert;
// import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.io.FileNotFoundException;

/**
*WirlessNetworks part 3.
*@author Colin Wallace
*@version 12/1/19
**/
public class WirelessNetworksPart3Test {


   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }
   /**
    *Test works.
    * @throws FileNotFoundException if file isn't found.
    */
   @Test public void workingTest() throws FileNotFoundException {
      WirelessNetwork.resetCount();
      String[] file = {"wireless_network_data1.txt"};
      WirelessNetworksPart3.main(file);
      Assert.assertEquals(0, WirelessNetwork.getCount());  
   }
  /**
    *fails.
    * @throws FileNotFoundException if file is not found.
    */
   @Test public void failedTest() throws FileNotFoundException {   
      WirelessNetwork.resetCount();
      String[] file = {"fdsfsfsdfs.txt"};
      WirelessNetworksPart3.main(file);
      Assert.assertEquals(0, WirelessNetwork.getCount());  
   }     
   /**
    *no file.
    * @throws FileNotFoundException if file is not found.
    */
   @Test public void noFileTest() throws FileNotFoundException {
      WirelessNetworksPart3 noFile = new WirelessNetworksPart3();
      String[] nF = { };
      WirelessNetworksPart3.main(nF);
      Assert.assertEquals(0, WirelessNetwork.getCount());  
   }
}