import java.util.Comparator;
/**
*
*@author Colin Wallace
*@version 11/13/19
**/
public class BandwidthComparator implements Comparator<WirelessNetwork> {
   /**
   *@param n2 network2
   *@param n1 network1
   *@return returns 1, -1, or 0 depending on if statement.
   **/
   public int compare(WirelessNetwork n1, WirelessNetwork n2) {
      
      if (n1.getBandwidth() > n2.getBandwidth()) {
         return 1;
      }
      else if (n1.getBandwidth() < n2.getBandwidth()) {
         return -1;
      }
      else {
         return 0;
      }
   }
}