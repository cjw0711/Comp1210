/**
*project 09 wifi class.
*@author Colin Wallace
*@version 11/8/19
**/

public class WiFi extends WirelessNetwork {
   private double modemCost = 0;
     /**
  *@param nameIn name input
   *@param monthlyCostIn monthlyCost input
   *@param bandwidthIn bandwidth input
       *@param modemCostIn modemCost input
  **/ 
   public WiFi(String nameIn, double bandwidthIn, double monthlyCostIn, 
      double modemCostIn) {
      super(nameIn, bandwidthIn, monthlyCostIn);
      modemCost = modemCostIn;
   }
   /**
  *
  *@return returns monthlyCost + modemcost.
  **/
   public double monthlyCost() {
      return monthlyCost + modemCost;
   }
   /**
  *
  *@return returns modemCost.
  **/
   public double getModemCost() {
      return modemCost;
   }
  /**
  *
  *@param modemCostIn modemCost input
  **/
   public void setModemCost(double modemCostIn) {
      this.modemCost = modemCostIn;
   }
}

