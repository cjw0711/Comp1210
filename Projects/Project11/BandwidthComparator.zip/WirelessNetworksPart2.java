import java.io.FileNotFoundException;
   /**
   *proj 10.
   *@author Colin Wallace
   *@version 11/22/19
   **/
public class WirelessNetworksPart2 {
   /**
   *@throws FileNotFoundException if file not found.
   *@param args command args.
   **/
   public static void main(String[] args) throws FileNotFoundException {
      if (args.length == 0)
      {
         System.out.println("File name expected as command line argument.");
         System.out.println("Program ending.");
      }
      else
      {
         WirelessNetworkList wList = new  WirelessNetworkList();
         wList.readFile(args[0]);
         System.out.print(wList.generateReport());
         System.out.print(wList.generateReportByName());
         System.out.print(wList.generateReportByBandwidth());
         System.out.print(wList.generateReportByMonthlyCost());
      }
   }
}