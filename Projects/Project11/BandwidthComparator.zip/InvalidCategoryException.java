/**
*proj11.
*@author Colin Wallace
*@version 11/13/19
**/
public class InvalidCategoryException extends Exception {
/**
*
*@param categoryIn categoryInput
**/
   public InvalidCategoryException(String categoryIn) {
      super("For category: " + categoryIn);
   }
}      

