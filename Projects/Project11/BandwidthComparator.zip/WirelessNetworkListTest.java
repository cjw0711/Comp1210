import org.junit.Assert;
// import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.io.FileNotFoundException;

   /**
   *proj 10.
   *@author Colin Wallace
   *@version 11/22/19
   **/
public class WirelessNetworkListTest {


   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }


   /** A test that always fails. 
   *@throws FileNotFoundException if file not found.
   **/
   @Test public void readFileTest() throws FileNotFoundException {
      WirelessNetworkList wNetwork = new WirelessNetworkList();
      wNetwork.readFile("wireless_network_data1.csv");
   }
   /**
   *@throws FileNotFoundException if file not found.
   *Test for name report.
   **/
   @Test public void generateReportByNameTest() throws FileNotFoundException {
      WirelessNetworkList wNetwork = new WirelessNetworkList();
      wNetwork.readFile("wireless_network_data1.csv");
      Assert.assertEquals("Name test", false, 
                           wNetwork.generateReportByName().contains("My Ipad"));
   }
    /**
   *
   *@throws FileNotFoundException if file not found.
   *Test for bandwidth report.
   **/
   @Test public void generateReportByBandwidthTest() 
      throws FileNotFoundException {
      WirelessNetworkList wNetwork = new WirelessNetworkList();
      wNetwork.readFile("wireless_network_data1.csv");
      Assert.assertEquals("Bandwidth test", 
         false, wNetwork.generateReportByBandwidth().contains("My Ipad"));
   }
    /**
   *
   *Test for monthlycost report.
   *@throws FileNotFoundException if file not found.
   **/
   @Test public void generateReportByMonthlyCostTest() 
      throws FileNotFoundException {
      WirelessNetworkList wNetwork = new WirelessNetworkList();
      wNetwork.readFile("wireless_network_data1.csv");
      Assert.assertEquals("MonthlyCost test", 
         false, wNetwork.generateReportByMonthlyCost().contains("My Ipad"));
   }
   /**
   *@throws FileNotFoundException if file not found.
   *invalid records test.
   **/
   @Test public void generateInvalidRecordsReportTest() 
      throws FileNotFoundException {
      WirelessNetworkList wNetwork = new WirelessNetworkList();
      wNetwork.readFile("wireless_network_data1.csv");
      Assert.assertEquals("invalidReports test", 
         false, wNetwork.generateInvalidRecordsReport().contains("My Ipad"));
   }
   /**
   *invalid test.
   *@throws FileNotFoundException if file not found.
   **/
   @Test public void addInvalidTest() 
      throws FileNotFoundException { 
      WirelessNetworkList wNetwork = new WirelessNetworkList(); 
      wNetwork.readFile("wireless_network_data1.csv");
      wNetwork.addInvalidRecord("invalid record"); }
      /**
   *getInvalidRecordsArray test.
   *@throws FileNotFoundException if file not found.
   **/
   @Test public void getInvalidRecordsArrayTest() 
      throws FileNotFoundException { 
      WirelessNetworkList wNetwork = new WirelessNetworkList(); 
      wNetwork.readFile("wireless_network_data1.csv");
      wNetwork.getInvalidRecordsArray(); }
      /**
   *getWirelessNetworksArray test.
   *@throws FileNotFoundException if file not found.
   **/
   @Test public void getWirelessNetworksArrayTest() 
      throws FileNotFoundException { 
      WirelessNetworkList wNetwork = new WirelessNetworkList(); 
      wNetwork.readFile("wireless_network_data1.csv");
      wNetwork.getWirelessNetworksArray(); }
   
}
