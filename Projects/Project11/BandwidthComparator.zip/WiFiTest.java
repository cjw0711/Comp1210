import org.junit.Assert;
// import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
*WiFi Test.
*@author Colin Wallace
*@version 11/8/19
**/
public class WiFiTest {

   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }


   /** A test that always fails. **/
   @Test public void getModemCostTest() {
      WiFi wi = new WiFi("My Wifi", 450, 40.00, 5.00);
      WiFi wiFalse = new WiFi("False Wifi", 250, 20, 2.50);
      double output = wi.getModemCost();
      Assert.assertEquals(40.0, 40.00, output);
      double output2 = wiFalse.getModemCost();
      Assert.assertFalse("", 20 == output2);
   }
   /**
   *Test for setModemCost.
   **/
   @Test public void setModemCostTest() {
      WiFi wi = new WiFi("My Wifi", 450, 40.00, 5.00);
      Assert.assertEquals(wi.getModemCost(), 5, .00001);
      wi.setModemCost(2);
      Assert.assertEquals(wi.getModemCost(), 2, .00001);
   }
      /**
      * gettter and setter test for name.
      **/
   @Test public void setNameTest() {
      WiFi wi = new WiFi("My Wifi", 450, 40.00, 5.00);
      WiFi wi2 = new WiFi("My Wifi", 450, 40.00, 5.00);
      Assert.assertEquals(wi.getName(), "My Wifi");
      wi.setName("My internet");
   }
   /**
   *
   **/
   @Test public void setBandwidth() {
      WiFi wi = new WiFi("My Wifi", 450, 40.00, 5.00);
      WiFi wi2 = new WiFi("My Wifi", 450, 40.00, 5.00);
      Assert.assertEquals(wi.getBandwidth(), 450, 0.00001);
      wi.setBandwidth(400);
   }
   /**
   *Test for setMonthlyFixedCost.
   **/
   @Test public void setMonthlyFixedCost() {
      WiFi wi = new WiFi("My Wifi", 450, 40.00, 5.00);
      Assert.assertEquals(wi.getMonthlyFixedCost(), 40.00, 0.00001);
      wi.setMonthlyFixedCost(41.00);
   }
   /**
   *Test for toString.
   **/
   @Test public void toStringTest() {
      WiFi wi = new WiFi("My Wifi", 450, 40.00, 5.00);
      WiFi wi2 = new WiFi("Bandwidth", 450, 40.00, 5.00);
      Assert.assertEquals(wi.toString().contains("My Wifi"), true);
      Assert.assertEquals(wi2.toString().contains("Bandwidth"), true);
   }
   /**
   *get and reset count test.
   **/
   @Test public void countTest() {
      WirelessNetwork.resetCount();
      Assert.assertEquals(0, WirelessNetwork.getCount());
   }
   /**
   *Test for compareTo.
   **/
   @Test public void compareTo() {
      WiFi wi = new WiFi("My Wifi", 450, 45.00, 5.00);
      WiFi wi2 = new WiFi("Bandwidth", 400, 30.00, 5.00);
      WiFi wi3 = new WiFi("Bandwidth", 550, 40.00, 5.00);
      WiFi wi4 = new WiFi("My Wifi", 650, 55.00, 5.00);
      Assert.assertEquals(11, wi.compareTo(wi2));
      Assert.assertEquals(11, wi.compareTo(wi3));
      Assert.assertEquals(0, wi.compareTo(wi4));
   
   }
}




