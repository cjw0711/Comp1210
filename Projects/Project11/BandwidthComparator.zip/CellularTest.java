import org.junit.Assert;
// import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
*FiveG Test.
*@author Colin Wallace
*@version 11/8/19
**/
public class CellularTest {


   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before public void setUp() {
   }


   /** A test that always fails. **/
   @Test public void getTimeTest() {
      Cellular cell = new Cellular("My Wifi", 450.00, 40.00, 5, 4);
      Cellular cellFalse = new Cellular("False Wifi", 250, 20.00, 6, 6);
      Assert.assertEquals("", 5, cell.getTime(), .000001);
      Assert.assertEquals("", 6, cellFalse.getTime(), .000001);
   }
      /**
      *Test for datalimit.
      **/
   @Test public void getDataLimitTest() {
      Cellular cell = new Cellular("My Wifi", 450.00, 40.00, 5, 4);
      Cellular cellFalse = new Cellular("False Wifi", 250, 20.00, 6, 6);
      Assert.assertEquals("", 4, cell.getDataLimit(), .000001);
      Assert.assertEquals("", 6, cellFalse.getDataLimit(), .000001);
   }
   /**
   *Test for setDataLimit.
   **/
   @Test public void setDataLimitTest() {
      Cellular cell = new Cellular("My Wifi", 450.00, 40.00, 5, 4);
      Assert.assertEquals(cell.getDataLimit(), 4, .00001);
      cell.setDataLimit(2);
      Assert.assertEquals(cell.getDataLimit(), 2, .00001);
   }
   /**
   *Test for setTime.
   **/
   @Test public void setTimeTest() {
      Cellular cell = new Cellular("My Wifi", 450.00, 40.00, 1200, 4);
      Assert.assertEquals(cell.getTime(), 1200, .00001);
      cell.setTime(1210);
      
   }
      /**
      *monthlyCost Test.
      **/
   @Test public void monthlyCostTest() {
      Cellular one = new Cellular("My Note", 20.00, 5.0, 1200.0, 1.0);
      Cellular two = new Cellular("My Book", 20.00, 5.0, 1200.0, 2.0);
      Assert.assertEquals("", 7.0, one.monthlyCost(), .000001);
      Assert.assertEquals("", 6.0, two.monthlyCost(), .000001);
   }
}
