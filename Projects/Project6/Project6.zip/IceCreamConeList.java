import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
/**
* Determines various functions of an array of an icecreamcone.
* Proj 05
* @author Colin Wallace
* 10/2/19
*/
public class IceCreamConeList
{
   private String listName;
   private ArrayList<IceCreamCone> iccList = 
      new ArrayList<IceCreamCone>();
/**
* Constructor for class.
* @param listNameIn the name for the array given.
* @param iccListIn icc list
*/   
   public IceCreamConeList(String listNameIn, ArrayList<IceCreamCone> iccListIn)
   {
      listName = listNameIn;
      iccList = iccListIn;
   }
/**
* Gets the name of the array.
* @return returns the name
*/   
   public String getName()
   {
      return listName; 
   }
/**
* Gets the number of IceCreamCones in the Array.
* @return returns the number of IceCreamCones.
*/   
   public int numberOfIceCreamCones() {
      if (iccList.size() < 1) {
         return 0;
      } 
      else {
         return iccList.size();
      }
   }
/**
* Calculates the total surface area of all the IceCreamCone in the array.
* @return returns the total surface area
*/   
   public double totalSurfaceArea() {
      if (iccList.size() > 0) {
         double total = 0;
         int index = 0;
         while (index < iccList.size()) {
            total += iccList.get(index).surfaceArea();
            index++;
         }
         return total;
      }
      else {
         return 0;
      }
   
   }
/**
* Calculates the total volume of all the IceCreamCones in the array.
* @return returns the total volume
*/   
   public double totalVolume() {
      if (iccList.size() > 0) {
         double output = 0;
         int i = 0;
         while (i < iccList.size()) {
            output += iccList.get(i).volume();
            i++;
         }
         return output;
      }
      else {
         return 0;
      }
   }
/**
* Calculates the average surface area of all the IceCreamCones in the array.
* @return returns the average surface area
*/  
   public double averageSurfaceArea() {
      if (iccList.size() > 0) {
         double output = (totalSurfaceArea() / numberOfIceCreamCones());
         return output;
      }
      else {
         return 0;
      }
   }
/**
* Calculates the average volume of all the IceCreamCones in the array.
* @return returns the average volume
*/  
   public double averageVolume() {
      if (iccList.size() > 0) {
         double output = (totalVolume() / numberOfIceCreamCones());
         return output;
      }
      else {
         return 0.0;
      }
   }
/**
* Prints out the name of the list as well as each IceCreamCone in the array.
* @return returns the output as described above
*/   
   public String toString() {
      int i = 0;
      String output = listName + "\n";
      while (i < numberOfIceCreamCones()) {
      
         output += "\n" + iccList.get(i).toString() + "\n";
         i++;
      }
      output += "\n";
      return output;     
   }
/**
* Prints out the summary of the the array.
* @return returns the summary
*/   
   public String summaryInfo()
   {
      DecimalFormat df = new DecimalFormat("#,##0.0##");
      String result = "";
      result += "----- Summary for " + getName() + " -----"; 
      result += "\nNumber of IceCreamCone Objects: " + numberOfIceCreamCones();
      result += "\nTotal Surface Area: " + df.format(totalSurfaceArea()); 
      result += "\nTotal Volume: "  + df.format(totalVolume());
      result += "\nAverage Surface Area: " + df.format(averageSurfaceArea());
      result += "\nAverage Volume: " + df.format(averageVolume()) + "\n";
      return result;
   }
// start of proj06  


/**
*gets arraylist of IceCreamCone.
*@return array list of IceCreamCone
*/ 
   public ArrayList<IceCreamCone> getList() {
      return iccList;
   }
/**
* Reads file for IceCreamConelist.
* @param fileNameIn for fileName to read
* @return IceCreamConeList
* @throws FileNotFoundException if the file cannot be opened.
*/
   public IceCreamConeList readFile(String fileNameIn) 
                                    throws FileNotFoundException {
                                  
                                 
            
      Scanner scanF = new Scanner(new File(fileNameIn));
      ArrayList<IceCreamCone> myiccList = new ArrayList<IceCreamCone>();
      String nameoflist = "";
      String label = "";
      double radius = 0;
      double height = 0;
      
      nameoflist = scanF.nextLine(); 
           
      while (scanF.hasNext()) {
         label = scanF.nextLine();
         radius = Double.parseDouble(scanF.nextLine());
         height = Double.parseDouble(scanF.nextLine());
         IceCreamCone iccobj = new IceCreamCone(label, radius, height);
         myiccList.add(iccobj);           
      }
      
      IceCreamConeList iccList2 = 
         new IceCreamConeList(nameoflist, myiccList);
      return iccList2;
   }
   
   /**
   *@param label adds label
   *@param height adds the height
   *@param radius adds the radius
   */
   public void addIceCreamCone(String label, double radius, double height) {
      IceCreamCone ic
         = new IceCreamCone(label, radius, height);
      iccList.add(ic);
   }
   /**
   *finds iceCreamCone in IceCreamConelist.
   *@return returns IceCreamCone
   *@param label input
   */
   public IceCreamCone findIceCreamCone(String label) {
      for (IceCreamCone ic: iccList) {
         if (ic.getLabel().equalsIgnoreCase(label)) {
            return ic;
         }
      } 
      return null;
   }
   /**
   *edits IceCreamCone.
   *@return IceCreamConeList
   *@param labelIn label input
   *@param heightIn height input
   *@param radiusIn radius input
   */
   public boolean editIceCreamCone(String labelIn, double radiusIn, 
      double heightIn) {
   
      boolean result = false;
      for (IceCreamCone ic : iccList) {
         if (ic.getLabel().equalsIgnoreCase(labelIn)) {
            ic.setRadius(radiusIn);
            ic.setHeight(heightIn);
            result = true;
            break;
         }
      
      }
      return result;
   }

   
  /**
   * Deletes an IceCreamCone from the list.
   * @return true if deleted else return false
   *@param labelIn 
   */    
   public IceCreamCone deleteIceCreamCone(String labelIn) {
      IceCreamCone iccdelete = findIceCreamCone(labelIn);
      
      if (iccdelete != null) {
         return iccList.remove(iccList.indexOf(iccdelete));
      } else {
         return null;
      }
   }
}