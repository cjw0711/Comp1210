
/**
*Act 08b.
*@author Colin Wallace
*@version 10/28/19
*/
public class Customer {
   private String customerName;
   private String customerlocation;
   private double customerbalance;
   /**
   *
   *@param nameIn Name input
   */
   public Customer(String nameIn) {
      customerName = nameIn;
      customerlocation = "";
      customerbalance = 0;
   }
   /**
   *
   *@return returns variable for balance
   */
   public double getBalance() { 
      return customerbalance;
   }
   /**
   *
   *@return returns variable for location
   */
   public String getLocation() { 
      return customerlocation;
   }
   /**
   * adds amount to balance.
   *@param amount double variable amount
   */
   public void changeBalance(double amount) { 
      customerbalance += amount + customerbalance;  
   }
   /**
   * sets location variable.
   *@param city String city
   *@param state String state
   */
   public void setLocation(String city, String state) { 
      customerlocation = city + ", " + state;
   }
   /**
   *
   *@param locationIn location Input
   */
   public void setLocation(String locationIn) {
      customerlocation = locationIn;
   }
   
   /**
   *
   *@return returns a string with the customers name, location, and balance.
   */
   public String toString() {
      return customerName + "\n"
         + customerlocation + "\n"
         + "$" + customerbalance;
   }
   /**
   *compareto method from directions.
   *@param obj object
   *@return returns 0, -1, 1
   */
   public int compareTo(Customer obj) {
   
      if (Math.abs(this.customerbalance - obj.getBalance()) < 0.000001) {
         return 0; // consider them equal and return 0
      }
      else if (this.customerbalance < obj.getBalance()) {
         return -1; // should return a negative number
      }
      else {
         return 1; // should return a positive number
      }
   }
}