/**
* Simple Program.
*
* Activity 1
* Colin Wallace comp 1210 lab
* 8/26/19
*/
public class StudentInfo {
   /**
    * Prints course information to std output.
    *
    * @param args Command line arguments (not used).
    */

   public static void main(String[] args) 
   {
      // print course description
      System.out.println("Name: Colin");
      System.out.println("Previous Computer Courses:");
      
      // print course description
      System.out.println("   None");
   }
}