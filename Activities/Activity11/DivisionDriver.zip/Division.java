/**
*act 11.
*@author Colin Wallace
*@version 11/18/19
**/
public class Division {
   /**
   *@param numerator int numerator
   *@param denominator int denominator
   *@return returns num / denom or 0.
   **/
   public static int intDivide(int numerator, int denominator) {
      try {
         return numerator / denominator;
      } catch (ArithmeticException e) {
         return 0;
      }
   }
 /**
 *@param numerator int numerator
 *@param denominator int denominator
 *@return returns double of numerator and denominator.
 **/
   public static double decimalDivide(int numerator, int denominator) {
      if (denominator == 0) {
         throw new IllegalArgumentException("The denominator "
            + "cannot be zero.");
      }
      return (double) numerator / denominator;
   }
}