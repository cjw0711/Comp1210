 /**
*@author Colin Wallace
*@version 11/3/19
*act 09 inheritance
*Lab section 010
**/
public class OnlineBook extends OnlineTextItem {
   
   protected String author;
    /**
   *@param priceIn price input.
   *@param nameIn name input.
   **/
   public OnlineBook(String nameIn, double priceIn)
   {
      super(nameIn, priceIn);
      author = "Author Not Listed"; }
    /**
   *
   *@return returns name and author and calulateCost.
   **/
   public String toString() {
   
      return name + " - " + author + ": $" + super.calculateCost(); }

    /**
   *
   *@param authorIn author input.
   **/
   public void setAuthor(String authorIn)
   {
      author = authorIn;
   }
}

