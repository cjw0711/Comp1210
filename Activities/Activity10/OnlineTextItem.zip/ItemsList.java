/**
*act 10.
*@author Colin Wallace
*@version 11/11/19
**/
public class ItemsList {
   private InventoryItem[] inventory;
   private int count;
   /**
   *
   **/
   public ItemsList() {
      inventory = new InventoryItem[20];
      count = 0;
   }
   /**
   *@param itemIn item input.
   **/
   public void addItem(InventoryItem itemIn) {
      inventory[count] = itemIn;
      count++;
   
   }
   /**
   *@param electronicsSurcharge 
   *@return returns total.
   **/
   public double calculateTotal(double electronicsSurcharge) {
      double total = 0;
      
      for (int i = 0; i < count; i++) {
         if (inventory[i] instanceof ElectronicsItem) {
            total += inventory[i].calculateCost() + electronicsSurcharge;
         } else {
            total += inventory[i].calculateCost();
         }
      }
      return total;
   }
/**
*@return returns result.
**/
   public String toString() {
      String result = "All inventory:\n\n";
      for (int i = 0; i < count; i++) {
         result += inventory[i] + "\n";
      }
   
      return result;
   
   }
}