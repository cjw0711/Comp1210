/**
*@author Colin Wallace
*@version 11/3/19
*act 09 inheritance
*Lab section 010
**/
public class InventoryItem {
   protected String name = "";
   protected double price = 0;
   private static double taxRate = 0;
   /**
   *@param nameIn name Input
   *@param priceIn price Input
   *Constructor
   **/
   public InventoryItem(String nameIn, double priceIn) {
      name = nameIn;
      price = priceIn;
   }
   /**
   *
   *@return returns name
   **/
   public String getName() {
      return name;
   }
   /**
   *@return returns price + (1 + taxRate).
   **/
   public double calculateCost() {
      return price * (1 + taxRate);
   }
   /**
   *@param taxRateIn taxRate Input
   *
   **/
   public static void setTaxRate(double taxRateIn) {
      taxRate = taxRateIn; 
   }
   /**
   *@return name + price + calculateCost.
   **/
   public String toString() {
      return name + ": $" + calculateCost();
   }
}