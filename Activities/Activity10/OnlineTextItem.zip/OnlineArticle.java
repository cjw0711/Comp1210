 /**
*@author Colin Wallace
*@version 11/3/19
*act 09 inheritance
*Lab section 010
**/
public class OnlineArticle extends OnlineTextItem
{
   private int wordCount;
   /**
   *@param nameIn name input
   *@param priceIn price input
   **/
   public OnlineArticle(String nameIn, double priceIn)
   {
      super(nameIn, priceIn);
      wordCount = 0;
   }
    /**
   *
   *@param wordCountIn word count input
   **/
   public void setWordCount(int wordCountIn)
   {
      wordCount = wordCountIn;
   }
}