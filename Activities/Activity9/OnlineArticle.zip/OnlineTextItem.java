/**
*@author Colin Wallace
*@version 11/3/19
*act 09 inheritance
*Lab section 010
**/
public abstract class OnlineTextItem extends InventoryItem {
   /**
   *@param nameIn name input.
   *@param priceIn price input.
   **/
   public OnlineTextItem(String nameIn, double priceIn)
   {
      super(nameIn, priceIn);
   
   }
   /**
   *
   *@return returns price.
   **/
   public double calulateCost()
   {
      return price;
   }
}
