   /**
*@author Colin Wallace
*@version 11/3/19
*act 09 inheritance
*Lab section 010
**/
public class ElectronicsItem extends InventoryItem {
   /**
   *Constant shipping_cost is set to 1.5.
   **/
   public static final double SHIPPING_COST = 1.5;
   protected double weight = 0;
    /**
    *@param nameIn name input
    *@param priceIn price input
    *@param weightIn weight input
    */
   public ElectronicsItem(String nameIn, double priceIn, double weightIn) {
      super(nameIn, priceIn); 
      weight = weightIn;
   }
   /**
   *@return returns calulateCost + Shippping Cost * weight.
   **/
   public double calculateCost() {
      return super.calculateCost() + (SHIPPING_COST * weight);
   }
}